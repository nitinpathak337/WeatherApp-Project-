



import React from 'react'
import { Component } from 'react'


const initialCities=["Delhi","Mumbai","Chennai","Kolkata","Bangalore"]

class App extends Component {

  state={
    data:[],
    
  }

  


  componentDidMount(){
    initialCities.map(eachItem=>this.fetchData(eachItem))
    
  }

  fetchData=async(city)=>{
    
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '8b7b09499cmshf975868ccaf33a7p14b983jsn913be2f6693d',
        'X-RapidAPI-Host': 'weather-by-api-ninjas.p.rapidapi.com'
      }
    };
  
  const response=await fetch(`https://weather-by-api-ninjas.p.rapidapi.com/v1/weather?city=${city}`, options)
  const weatherData= await response.json()
  const updatedWeatherData={...weatherData,city}
  console.log(weatherData);
  this.setState(prevState=>({data:[...prevState.data,updatedWeatherData]}))
 
  }

  searchInput=(event)=>{
      
      if (event.key==="Enter"){
        
        this.fetchData(event.target.value)
      }
      
  }

  
  render(){
    const {data}=this.state
    
    const shownData=data.slice(-6,-1);
    
  return (
    <>
      <h1>Weather App</h1>
      <input type="text" placeholder='Search City' onChange={this.searchInput} />
      <ul>
        {shownData.map((eachItem)=>{
          return(
          <li>
            <h1>City:{eachItem.city}</h1>
            <h1>Temp :{eachItem.temp}</h1>
          </li>)
        })}
      </ul>
    </>
  )
  }
}

export default App




